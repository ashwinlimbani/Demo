#define IF 257
#define ID 258
#define RELOP 259
#define EQ 260
#define PLUS 261
#define SEMIC 262
#define STCB 263
#define EDCB 264
#define DIGIT 265
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union
{
	char cval[10];
	int dval;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
