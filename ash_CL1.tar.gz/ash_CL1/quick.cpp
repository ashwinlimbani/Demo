#include<iostream>
#include<omp.h>
#include<cstdlib>

using namespace std;

int thread=0;

class QS
{
public:
void swap(int *n1,int *n2)
{
	int temp = *n1;
	*n1 = *n2;
	*n2 = temp;
}

int partition(int arr[],int low,int high)
{
	int i=low-1;
	int pivot =arr[high];
	for(int j=low;j<=high-1;j++)
	{
		if(arr[j]<=pivot)
		{
			i++;
			swap(&arr[j],&arr[i]);
		}
	}
swap(&arr[i+1],&arr[high]);
return (i+1);
}

void quick(int arr[],int low,int high)
{
	if(low<high)
	{
		int q = partition(arr,low,high);
		cout<<"Pivot at index "<<q<<" found at "<<thread<<endl;

		#pragma omp parallel sections
		{
			#pragma omp section
			{
				thread++;
				quick(arr,low,q-1);
			}
			#pragma omp section
			{
				thread++;
				quick(arr,q+1,high);
			}
		}
	}
}
};
int main()
{
	int arr[100];
	QS q;
	srand( time(0));
	#pragma omp parallel for
	for(int i=0; i<100;i++)
	{
		arr[i] = rand()%100;
	}
	int n =100;

	cout<<"\nUnSorted Array:\n";

	for(int i=0;i<n;i++)
		cout<<arr[i]<<" ";

	double st = omp_get_wtime();
	q.quick(arr,0,n-1);
	double et = omp_get_wtime();

	cout<<"\nTime needed is : "<<et-st<<endl;

	cout<<"\nSorted Array:\n";

	for(int i=0;i<n;i++)
		cout<<arr[i]<<" ";
	cout<<endl;

	return 0;
}
