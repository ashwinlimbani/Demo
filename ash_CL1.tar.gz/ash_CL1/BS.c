#include<stdio.h>
#include<omp.h>

void Insertion(int n);
int BS(int a[],int,int,int);

int a[20];
int main()
{
	int n,i,j;
	printf("\nEnter the number of elements:");
	scanf("%d",&n);
	printf("\nEnter no. in array:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}

	Insertion(n);

	printf("\nSorted array :\n");
	for(i=0;i<n;i++)
		printf("%d\t",a[i]);

	int num,p;
	printf("\n\nEnter no. to search:\n");
	scanf("%d",&num);

	p = BS(a,0,n-1,num);

	if(p==-1)
		printf("\nNumber is not present...");
	else
		printf("\nNumber is at : %d\n",p);

	return 0;
}

void Insertion(int n)
{
	int i,j,temp;
	for(i=1;i<n;i++)
	{
		temp = a[i];
		for(j=i-1;j>=0 && a[j]>temp;j--)
		{
			a[j+1] = a[j];
		}
		a[j+1]=temp;
	}
}

int BS(int a[],int top,int bottom,int num)
{
	int tid,index,mid;
	if(bottom>=top)
	{
		mid = (top+bottom)/2;
		#pragma omp parallel sections
		{
		#pragma omp section
		{
			tid = omp_get_thread_num();
			printf("\nThread %d checking",tid);
			if(a[mid]==num)
				index = mid+1;
		}
		#pragma omp section
		{
			if(num < a[mid])
				index = BS(a,top,mid-1,num);
				
		}
		#pragma omp section
		{
			if(num > a[mid])
				index = BS(a,mid+1,bottom,num);

		}
		}
	}
	else
		index = -1;

	return index;
}
