#include<iostream>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

int main()
{
	int n,m1,m2,oldm1,oldm2,it=0;
	int d1,d2,k=0,j=0;
	
	cout<<"Enter number of elements: \n";
	cin>>n;

	int a[n],b[n],c[n];

	for(int i=0; i<n;i++)
	{
		cout<<"Enter Element "<<i+1<<" :\n";
		cin>>a[i];
	}
	cout<<"Initial data points \n";
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
	cout<<"\nInitial mean1 : ";
	cin>>m1;
	cout<<"\nInitial mean2 : ";
	cin>>m2;

	do
	{
		it++;
		j=k=0;
		oldm1=m1;
		oldm2=m2;

		for(int i=0;i<n;i++)
		{
			d1 = abs(a[i]-m1);
			d2 = abs(a[i]-m2);

			if(d1<d2)
			{
				b[j]=a[i];
				j++;
			}
			else
			{
				c[k]=a[i];
				k++;
			}
		}
		m1=m2=0;
		for(int i=0;i<j;i++)
		{
			m1=m1+b[i];
		}
		m1=m1/j;
		for(int i=0;i<k;i++)
			m2=m2+c[i];
		m2=m2/k;

		cout<<"==========ITERATION"<<it<<"=========\n";
		cout<<"Cluster 1 : \n";
		for(int i=0;i<j;i++)
		{
			cout<<b[i]<<" ";
		}
		cout<<"\nCluster Head : "<<m1;

		cout<<"\nCluster 2 : \n";
		for(int i=0;i<k;i++)
		{
			cout<<c[i]<<" ";
		}
		cout<<"\nCluster Head : "<<m2;
	}while(oldm1!=m1 && oldm2!=m2);


		cout<<"==========FINAL=========\n";
		cout<<"Cluster 1 : \n";
		for(int i=0;i<j;i++)
		{
			cout<<b[i]<<" ";
		}
		cout<<"\nCluster Head : "<<m1;

		cout<<"\nCluster 2 : \n";
		for(int i=0;i<k;i++)
		{
			cout<<c[i]<<" ";
		}
		cout<<"\nCluster Head : "<<m2;

	return 0;
}
