#include<stdio.h>

int main()
{
	int a[9];
	float x,y,z;
	//abd
	/*
	xyz
	*/

	printf("OK");

	if(x>y)
	{
		x=y+z;
	}
}
